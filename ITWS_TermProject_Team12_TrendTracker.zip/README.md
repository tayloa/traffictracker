TrendTracker is an application by Aaron Taylor and Justin Gaskins that is being built
to better analyze trending topics on the web. Currently it has two main pages; a landing and
dashboard page.
