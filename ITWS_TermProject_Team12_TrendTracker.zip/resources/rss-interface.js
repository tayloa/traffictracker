
// function getRSS(formObj) {
//
//   console.log(formObj.query.value);
//   var url ="https://twitter.com/hashtag/Kanye";
//   var scripts = document.getElementsByTagName( "script" );
    // for ( var i = 0; i < scripts.length; ++ i )
    // {
    //    if ( scripts[i].src == "myfile1.js" )
    //    {
    //       scripts[i].parentNode.innerHTML = "new content";
    //    }
    // };
  // $().
  // let request = new XMLHttpRequest();
  // let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=[API-KEY-GOES-HERE]`;
  // var url = "https://newsapi.org/v2/everything?q=" + "formObj.query" + "apiKey=fdbaa595a9f840839dc6ac3024070bf6";
  //
  // // call google news for RSS feed based on query and input dates
  // let url = "https://newsapi.org/v2/everything?q=" + "query" + "&from=" + "yyyy-mm-dd" + "&to=" + "yyyy-mm-dd" +
  // "&sortBy=popularity&apiKey=fdbaa595a9f840839dc6ac3024070bf6";
  //
  // request.onreadystatechange = function() {
  //   if (this.readyState === 4 && this.status === 200) {
  //     let response = JSON.parse(this.responseText);
  //     getElements(response);
  //   }
  // }
  //
  // request.open("GET", url, true);
  // request.send();
  // return;
// }
//
// function getTweets(formObj) {
//   console.log(formObj.query.value);
//   var url ="https://twitter.com/hashtag/" + formObj.query.value;
//   var scripts = document.getElementsByTagName( "script" );
// }
