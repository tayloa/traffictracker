</div>
  <div id="footer" style="position: relative;">
    Aaron Tayor, Justin Gaskins 2018, Rensselaer Polytechnic Institute
    <div class="btn-group" role="group" aria-label="Basic example">
      <a href="https://github.com/tayloa/trendtracker">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fab fa-github"></i></button>
      </a>
    </div
  </div>
  <script  src="http://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
  <script src="http://code.jquery.com/ui/1.12.1/jquery-ui.min.js"
  integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU="
  crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"
  integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
  <script type="text/javascript" src="resources/rss-interface.js"></script>
  <script type="text/javascript" src="resources/dashboard.js"></script>
  <script type="text/javascript" src="resources/trends_google.js"></script>
  <script type="text/javascript" src="resources/feed.js"></script>
</body>
</html>
